package quiz.app.reviewer.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity

public class Results {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Integer ResultID;
	private int rightScore;
	private int wrongScore;
	private int finalScore;
	private int totalQuestions;
	public Integer getResultID() {
		return ResultID;
	}
	public void setResultID(Integer resultID) {
		ResultID = resultID;
	}
	public int getRightScore() {
		return rightScore;
	}
	public void setRightScore(int rightScore) {
		this.rightScore = rightScore;
	}
	public int getWrongScore() {
		return wrongScore;
	}
	public void setWrongScore(int wrongScore) {
		this.wrongScore = wrongScore;
	}
	public int getFinalScore() {
		return finalScore;
	}
	public void setFinalScore(int finalScore) {
		this.finalScore = finalScore;
	}
	public int getTotalQuestions() {
		return totalQuestions;
	}
	public void setTotalQuestions(int totalQuestions) {
		this.totalQuestions = totalQuestions;
	}
	
	

}
